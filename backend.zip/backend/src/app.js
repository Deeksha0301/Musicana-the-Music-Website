let express = require("express")
let path = require("path")
let hbs = require('hbs')
require("./conn")
let app = express()


app.get("/",(req,res)=>{
    res.render('index');
})

app.listen("3000", ()=>{
    console.log("server is listening to port 3000")
})